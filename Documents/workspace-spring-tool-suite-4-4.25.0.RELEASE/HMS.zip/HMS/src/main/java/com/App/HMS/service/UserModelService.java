package com.App.HMS.service;

import com.App.HMS.dto.UserModelDto;
import com.App.HMS.model.UserModel;

public interface UserModelService {

	
	UserModel save(UserModelDto usermodeldto);
}
