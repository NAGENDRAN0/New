package com.App.HMS.chat;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "chat_messages")
public class ChatMessage {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
    private String content;
    private String sender;
    @Enumerated(EnumType.STRING)
    private MessageType messagetype;

    public ChatMessage() {
    }

    public ChatMessage(String content, String sender, MessageType messagetype) {
        this.content = content;
        this.sender = sender;
        this.messagetype = messagetype;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public MessageType getMessagetype() {
        return messagetype;
    }

    public void setMessagetype(MessageType messagetype) {
        this.messagetype = messagetype;
    }

    // Manual Builder Class
    public static class Builder {
        private String content;
        private String sender;
        private MessageType messagetype;

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder sender(String sender) {
            this.sender = sender;
            return this;
        }

        public Builder messagetype(MessageType messagetype) {
            this.messagetype = messagetype;
            return this;
        }

        public ChatMessage build() {
            return new ChatMessage(content, sender, messagetype);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}
