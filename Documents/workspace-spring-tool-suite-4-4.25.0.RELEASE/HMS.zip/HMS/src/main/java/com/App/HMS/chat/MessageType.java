package com.App.HMS.chat;




public enum MessageType {
    CHAT, JOIN, LEAVE
}